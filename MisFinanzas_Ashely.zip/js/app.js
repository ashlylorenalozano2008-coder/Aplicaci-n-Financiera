// Elementos
const descripcionEl = document.getElementById('descripcion');
const montoEl = document.getElementById('monto');
const tipoEl = document.getElementById('tipo');
const agregarBtn = document.getElementById('agregar');
const listaEl = document.getElementById('lista');
const ingresosEl = document.getElementById('ingresos');
const gastosEl = document.getElementById('gastos');
const balanceEl = document.getElementById('balance');
const fraseFooterEl = document.getElementById('fraseFooter');
const fraseResumenEl = document.getElementById('fraseResumen');
const imprimirBtn = document.getElementById('imprimir');

// Totales
let ingresos = 0;
let gastos = 0;

// Formato COP
const formatoCOP = new Intl.NumberFormat('es-CO', {style:'currency',currency:'COP',minimumFractionDigits:0})

// Frases
const frases = [
  "Cada peso cuenta: cuida tu dinero, cuida tu futuro.",
  "Ahorra hoy para disfrutar mañana.",
  "Tu esfuerzo se convierte en prosperidad.",
  "El dinero bien cuidado es tranquilidad asegurada.",
  "Save today, shine tomorrow ✨",
  "Small savings, big dreams 🌸",
  "El dinero no da la felicidad, pero la organiza ⭐",
  "Controla tus gastos y controlarás tus sueños 💖",
  "¡Vas muy bien!",
  "Sigue cuidando tu dinero ✨",
  "Un paso más hacia tus metas 💖",
  "Pequeños ahorros hacen grandes logros ⭐",
  "Cada decisión cuenta 🌸",
  "Lo que ahorras hoy, lo agradeces mañana.",
  "Disciplina hoy, libertad mañana 💎"
];

// Mostrar dos frases diferentes al cargar
function obtenerDosFrases(){
  const i = Math.floor(Math.random()*frases.length);
  let j;
  do{ j = Math.floor(Math.random()*frases.length); } while(j===i);
  return [frases[i],frases[j]];
}
const [f1,f2] = obtenerDosFrases();
fraseResumenEl.textContent = f1;
fraseFooterEl.textContent = f2;

// Formatear monto mientras escribe (puntos colombia)
montoEl.addEventListener('input', (e)=>{
  let val = e.target.value.replace(/\./g,'');
  // permitir borrar
  if(val==='') return e.target.value='';
  // quitar cualquier letra o comas
  val = val.replace(/[^0-9]/g,'');
  // formatear
  e.target.value = Number(val).toLocaleString('es-CO');
});

// Agregar movimiento
agregarBtn.addEventListener('click', ()=>{
  const desc = descripcionEl.value.trim();
  const raw = montoEl.value.replace(/\./g,'');
  if(desc==='' || raw===''){ alert('Por favor completa todos los campos'); return; }
  const monto = parseInt(raw,10);
  const tipo = tipoEl.value;

  // crear elemento
  const div = document.createElement('div');
  div.className = 'movimiento '+tipo;
  const spanDesc = document.createElement('span');
  spanDesc.textContent = desc;
  const spanMonto = document.createElement('span');
  spanMonto.textContent = formatoCOP.format(monto);
  div.appendChild(spanDesc);
  div.appendChild(spanMonto);
  listaEl.prepend(div);

  // actualizar totales
  if(tipo==='ingreso') ingresos += monto;
  else gastos += monto;
  actualizarResumen();

  // limpiar
  descripcionEl.value = '';
  montoEl.value = '';
});

function actualizarResumen(){
  ingresosEl.textContent = formatoCOP.format(ingresos);
  gastosEl.textContent = formatoCOP.format(gastos);
  balanceEl.textContent = formatoCOP.format(ingresos - gastos);
  // cambiar color balance segun positivo/negativo
  if(ingresos - gastos < 0) balanceEl.style.color = 'red';
  else balanceEl.style.color = 'green';
}

// Imprimir (imprime toda la página; el CSS para imprimir puede ajustarse si quieres)
imprimirBtn.addEventListener('click', ()=> window.print());
